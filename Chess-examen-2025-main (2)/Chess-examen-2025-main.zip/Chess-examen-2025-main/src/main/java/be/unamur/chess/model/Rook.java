package be.unamur.chess.model;

import java.awt.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Rook piece class.
 */
public class Rook extends Piece {

    public Rook(boolean isWhite) {
        super(isWhite);
    }

    @Override
    public Set<Point> getValidMoves(Piece[][] boardState, int row, int col) {
        Set<Point> moves = new HashSet<>();

        // Add rook movement logic (horizontal and vertical)
        for (int[] direction : new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}}) {
            for (int step = 1; step < 8; step++) {
                int newRow = row + direction[0] * step;
                int newCol = col + direction[1] * step;

                if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                    Piece target = boardState[newRow][newCol];
                    if (target == null) {
                        moves.add(new Point(newRow, newCol));
                    } else {
                        if (target.isWhite() != isWhite) {
                            moves.add(new Point(newRow, newCol));
                        }
                        break;
                    }
                } else {
                    break;
                }
            }
        }

        return moves;
    }

    @Override
    public String toString() {
        return isWhite() ? "WRook" : "BRook";
    }
}
