package be.unamur.chess.io;

import java.io.*;

import be.unamur.chess.model.*;

/**
 * The utility class for saving and loading chess games in JSON format.
 */
public class ChessFileHandler {

    /**
     * Saves and loads the current game state to and from a file in JSON format manually.
     *
     * @param boardState the current board state.
     * @param file       the file to save to or load from.
     * @param save       true to save, false to load.
     * @return the loaded board state (if loading) or null (if saving).
     * @throws IOException if an I/O error occurs.
     */
    public static Piece[][] saveOrLoadGame(Piece[][] boardState, File file, boolean save) throws IOException {
        if (save) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write("[");
                for (int row = 0; row < boardState.length; row++) {
                    writer.write("[");
                    for (int col = 0; col < boardState[row].length; col++) {
                        Piece piece = boardState[row][col];
                        if (piece != null) {
                            writer.write(String.format("{\"type\":\"%s\",\"white\":%b}",
                                    piece.getClass().getSimpleName(), piece.isWhite()));
                        } else {
                            writer.write("null");
                        }
                        if (col < boardState[row].length - 1) {
                            writer.write(",");
                        }
                    }
                    writer.write("]");
                    if (row < boardState.length - 1) {
                        writer.write(",");
                    }
                }
                writer.write("]");
            }
            return null;
        } else {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                StringBuilder json = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    json.append(line);
                }
                String content = json.toString();
                Piece[][] newBoardState = new Piece[8][8];
                content = content.substring(1, content.length() - 1); // Remove outer brackets
                String[] rows = content.split("\\],\\[");

                for (int row = 0; row < rows.length; row++) {
                    String rowContent = rows[row].replaceAll("[\\[\\]\"]", "");
                    String[] cols = rowContent.split(",");
                    for (int col = 0; col < cols.length; col++) {
                        String cell = cols[col].trim();
                        if (!cell.equals("null")) {
                            String type = cell.split(",")[0].split(":")[1].replace("\"", "");
                            boolean isWhite = Boolean.parseBoolean(cell.split(",")[1].split(":")[1].replace("}", ""));
                            newBoardState[row][col] = switch (type) {
                                case "Pawn" -> new Pawn(isWhite);
                                case "Rook" -> new Rook(isWhite);
                                case "Knight" -> new Knight(isWhite);
                                case "Bishop" -> new Bishop(isWhite);
                                case "Queen" -> new Queen(isWhite);
                                case "King" -> new King(isWhite);
                                default -> null;
                            };
                        }
                    }
                }
                return newBoardState;
            }
        }
    }
}

