package be.unamur.chess.ai;

import be.unamur.chess.model.Piece;

import java.awt.*;

/**
 * A basic strategy class to implement a simple AI for chess.
 */
public class Simple_Strategy implements Strategy {

    @Override
    public Point[] getNextMove(Piece[][] board_state, boolean isWhite) {
        Point[] best_move = null;

        // Iterate through all pieces on the board
        for (int row = 0; row < board_state.length; row++) {
            for (int col = 0; col < board_state[row].length; col++) {
                Piece current_piece = board_state[row][col];
                if (current_piece != null && current_piece.isWhite() == isWhite) {

                    // Get valid moves for the current_piece
                    for (Point move : current_piece.getValidMoves(board_state, row, col)) {
                        // Example basic strategy: take the first valid move found
                        if (best_move == null) {
                            best_move = new Point[]{new Point(row, col), move};
                        }

                        // Example advanced strategy: prefer capturing moves
                        if (board_state[move.x][move.y] != null && board_state[move.x][move.y].isWhite() != isWhite) {
                            return new Point[]{new Point(row, col), move};
                        }
                    }
                }
            }
        }

        return best_move;
    }

}
