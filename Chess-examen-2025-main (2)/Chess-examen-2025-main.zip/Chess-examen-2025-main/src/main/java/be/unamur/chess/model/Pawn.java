package be.unamur.chess.model;

import java.awt.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Pawn piece class.
 */
public class Pawn extends Piece {

    public Pawn(boolean isWhite) {
        super(isWhite);
    }

    @Override
    public Set<Point> getValidMoves(Piece[][] boardState, int row, int col) {
        Set<Point> moves = new HashSet<>();
        int direction = isWhite ? -1 : 1;

        // Forward move
        if (row + direction >= 0 && row + direction < 8 && boardState[row + direction][col] == null) {
            moves.add(new Point(row + direction, col));
            if ((isWhite && row == 6) || (!isWhite && row == 1)) {
                if (boardState[row + 2 * direction][col] == null) {
                    moves.add(new Point(row + 2 * direction, col));
                }
            }
        }

        // Captures
        int[] captureOffsets = {-1, 1};
        for (int offset : captureOffsets) {
            int captureCol = col + offset;
            if (captureCol >= 0 && captureCol < 8 && row + direction >= 0 && row + direction < 8) {
                Piece target = boardState[row + direction][captureCol];
                if (target != null && target.isWhite() != isWhite) {
                    moves.add(new Point(row + direction, captureCol));
                }
            }
        }

        return moves;
    }

    @Override
    public String toString() {
        return isWhite() ? "WPawn" : "BPawn";
    }
}
