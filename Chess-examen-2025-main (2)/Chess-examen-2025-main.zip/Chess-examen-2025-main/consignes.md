# INFOM124 Vérification et validation logicielle : Examen (janvier 2025)

- Nom : *indiquez ici votre nom*
- Prénom : *indiquez ici votre prénom*
- GitHub id: *indiquez ici votre id GitHub*

## Consignes générales

- La durée maximale de l’examen est de **4 heures**.
- L'examen est à cours ouvert.
- L'examen est individuel, la communication avec autrui est interdite. En particulier l'utilisation de messagerie instantanée, de mails ou de tout autre système de partage d'information avec d'autres étudiant.e.s passant l'examen seront considérés comme une tricherie.
- Les réponses (aussi appelés rapports) doivent être indiquées dans les espaces prévus à cet effet dans le présent document, ainsi qu'éventuellement dans le code source remis au début de l'examen.

## Méthode de cotation

Le but de l'examen est de démontrer votre capacité à analyser la qualité globale d'une codebase aux moyens des outils et techniques vues en cours.

Pour vous aider à adopter une approche structurée, 9 "pistes guidées" vous sont fournies plus loin dans ce document. Ces pistes, comme leur nom l'indique, ont pour but de vous orienter vers des zones de la codebase dans lesquels des problèmes sont assurément présents. Elles sont également divisées en sous-questions vous ayant pour bu de vous aider à structurer votre manière de rapporter les soucis de qualité en question.

**Il n'est pas nécessaire de répondre à toutes les sous-questions afin d'engranger des points pour cette question.** Au plus vous allez loin, au plus la piste vous rapportera de points. Très concrètement, le rapport que vous faites sous chaque piste guidée sera évalué comme suit :

* *Insuffisant* : le rapport est vide ou totalement erroné (0 points).
* *Insuffisfaisant* : le rapport est parcellaire ou "à côté de la plaque", mais comporte des éléments factuels **et** originaux(*) (0.25 point).
* *Satisfaisant* : le diagnostic et la correction proposés dans le rapport sont corrects et étayés (0.5 point).
* *Bon* : le diagnostic, la correction et l'action préventive proposés dans le rapport sont corrects et étayés (0.75 point).
* *Très bon* : le diagnostic, la correction et l'action préventive proposés dans le rapport sont corrects et étayés et la correction a été appliquées dans le code source (1 point).

(*) Par "originaux", on entend un élément ayant fait l'objet d'une réflexion et/ou interprétation par l'étudiant ; recopier textuellement un morceau du rapport de SonarQube, Checkstyle ou autre ne vous accordera pas de points.

Les 9 pistes guidées sont réparties en 3 catégories liées au type de problème abordé (code smells, defects, bad development practices). Le seuil minimum de réussite (10/20) est atteint si vous répondez de manière satisfaisante à 5 questions, **avec au moins 1 question par catégorie**.

Votre score final sera alors :

* 4/20 (si vous avez répondu de manière satisfaisante à une seule catégorie).
* 7/20 (si vous avez répondu de manière satisfaisante à deux catégories)
* 10 + X(**) (si vous avez répondu de manière satisfaisante à trois catégories)

(**) X étant une "marge de réussite" comprise entre 0 et 10 et calculée sur base de la qualité des réponses fournies aux différentes pistes.

Veuillez noter qu'une 10e piste (*Analyse complémentaire*) est ouverte et vous demande de faire une analyse globale de la qualité du projet sur base des différents rapports d'analyse qui vous sont fournis. Celle-ci compte dans la marge de réussite ci-dessus.

## Projet à analyser

Le projet à tester est un jeu d'échec où les joueurs s'affrontent sur un plateau de 64 cases alternées en noir et blanc. L'échiquier est orienté avec une case blanche en bas à droite. Chaque joueur commence avec 16 pièces : 8 pions (pawns), 2 tours (rooks), 2 cavaliers (knights), 2 fous (bishops), 1 dame (queen), 1 roi (king). Les pièces blanches sont placées sur les deux premières rangées, les noires sur les deux dernières.

L’objectif est de *mattre* le roi adverse (échec et mat), c’est-à-dire de le mettre dans une position où il est attaqué et ne peut pas s’échapper. Une partie peut aussi se terminer par un nul (match nul) dans certains cas.

Chaque type de pièce se déplace selon des règles spécifiques. Le roi peut se déplacer d'une case dans toutes les directions. La dame se déplace horizontalement, verticalement ou en diagonale sur n'importe quelle distance. La tour se déplace horizontalement ou verticalement sur n'importe quelle distance, tandis que le fou se déplace uniquement en diagonale. Le cavalier suit un mouvement particulier en "L" (deux cases dans une direction, puis une case perpendiculaire) et peut sauter par-dessus d'autres pièces. Le pion avance d'une case vers l'avant (ou de deux cases lors de son premier mouvement) et capture en diagonale. Lorsqu'un pion atteint la dernière rangée, il est promu en dame, tour, fou ou cavalier au choix du joueur.

Lorsqu'un roi est attaqué, il est en échec. Le joueur doit alors réagir immédiatement en déplaçant le roi, en bloquant l'attaque avec une autre pièce ou en capturant la pièce menaçante. Si aucune de ces options n'est possible, le roi est en échec et mat, et la partie est perdue. La promotion d’un pion se produit lorsqu'il atteint la dernière rangée et peut être transformé en une autre pièce. La partie se termine de plusieurs façons. Une victoire est obtenue par échec et mat, abandon de l'adversaire ou dépassement de temps dans une partie chronométrée. Un nul peut survenir dans divers cas, tels que le pat (lorsque le joueur au trait n’a aucun coup légal et que son roi n’est pas en échec), un accord mutuel entre les joueurs, ou lorsque le matériel restant ne permet pas de mater. *À noter que la détection d'un échec ou de la fin de partie ne sont pas implémentés dans le projet.*

### Structure du projet

Le projet utilise Maven. Pour rappel, la structure d'un projet Maven est la suivante :
- `src/main/java` contient le code source de l'application.
- `src/test/java` contient les tests de l'application.
- `target/` contient les résultats du *build* (code compilé, résultats des tests, rapports d'analyse, etc.).

La classe `be.unamur.chess.ChessGame` est la classe principale qui gère le lancement d'une partie.

### Configuration du build

La commande suivante permet de lancer le *build* du projet, à savoir la compilation et l'exécution des tests :
```
mvn clean package
``` 
Si Maven n'est pas installé sur votre machine, vous pouvez également exécuter depuis la racine du projet (sur Linux et MacOS) :
```
./mvnw clean package
``` 
Ou sur Windows :
```
mvnw.cmd clean package
``` 

La configuration du build inclus déjà toute une série d'outils d'analyse :
- Checkstyle, un outil d'analyse statique permettant de vérifier que les conventions d'écriture de code sont respectées. L'outil offre une configuration par défaut qui peut être adaptée et customisée selon les besoins.
- PMD, un outil d'analyse statique permettant de repérer les erreurs de programmation courantes.
- SpotBugs, un outil d'analyse statique permettant de repérer des bugs.
- JaCoCo, un outil d'analyse dynamique fournissant des indications sur la couverture structurelle des tests.
- PIT, un outil d'analyse dynamique permettant d'effectuer une analyse de mutation.

**Note :** L'archive .zip qui vous a été remise contient déjà une copie des différents rapports pour la version du projet dans le dossier `rapports/`. **Ces rapports sont suffisants pour répondre à la plus grande partie des pistes ci-après.** Si vous voulez aller plus loin, il est également possible de re-générer ces rapports via la commande suivante (ou `./mvnw` ou `mvnw.cmd`) :
```
mvn clean test org.pitest:pitest-maven:mutationCoverage site
``` 
Une fois la commande exécutée, les rapports générés sont disponibles dans `target/site/index.html` (sous le menu à gauche *Project Reports*).

****************************************************************************************

## Pistes guidées - Mauvaises pratiques de développement

### It's a kind of magic

Suite à une demande de la part des commanditaires du jeu de pouvoir étendre l'échiquier au-delà d'une grille de 8x8, une étude d'impact a montré que cela nécessiterait un grand nombre de petites modifications un peu partout dans le code. En particulier, la création de la grille et le positionnement des pièces sur celle-ci dans la classe `ChessModel` et la vérification des mouvements valides pour les différentes pièces (implémentations de la méthode `getValidMoves`) ont été identifiées comme potentiellement fortement impactés.  

#### Technique(s) utilisée(s) pour poser le diagnostic
*Expliquez comment vous avez identifié le problème. Pensez à indiquer sur quoi vous vous basez pour confirmer la nature du problème (mesures, rapport d'analyse, etc.).*



#### Diagnostic
*Indiquez ci-dessous le problème identifié et les impacts qu'il pourrait avoir sur la maintenabilité du code.*



#### Action(s) corrective(s)
*Indiquez comment corriger le problème. Alternativement, effectuez la correction dans le code source et indiquez-le ci-dessous, nous irons alors voir dans le code directement.*



#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher que cette mauvaise pratique ne se répande dans le projet. Indiquez les techniques et/ou outils à utiliser pour prévenir ce genre de mauvaise pratique. Nous attendons plus ici qu'une réponse générique de type "il faut faire de la review de code" ou "il faut utiliser SonarQube". Par exemple, indiquez ce qu'il faut prendre en compte dans la review et ce sur quoi le reviewer peut se baser pour identifier la mauvaise pratique.*



### Cognitive overflow

Un junior de l'équipe doit mettre à jour la méthode `getValidMoves`de la classe `Pawn`mais n'y arrive pas sans que ses modifications ne cassent les tests. Vérifiez s'il n'y a pas un problème avec la méthode ne permettant pas à un novice de comprendre facilement ce que fait la méthode.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Expliquez comment vous avez identifié le problème. Pensez à indiquer sur quoi vous vous basez pour confirmer la nature du problème (mesures, rapport d'analyse, etc.).*



#### Diagnostic
*Indiquez ci-dessous le problème identifié et les impacts qu'il pourrait avoir sur la maintenabilité du code.*



#### Action(s) corrective(s)
*Indiquez comment corriger le problème. Alternativement, effectuez la correction dans le code source et indiquez-le ci-dessous, nous irons alors voir dans le code directement.*



#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher que cette mauvaise pratique ne se répande dans le projet. Indiquez les techniques et/ou outils à utiliser pour prévenir ce genre de défauts. Nous attendons plus ici qu'une réponse générique de type "il faut faire de la review de code" ou "il faut utiliser SonarQube". Par exemple, indiquez ce qu'il faut prendre en compte dans la review et ce sur quoi le reviewer peut se baser pour identifier la mauvaise pratique.*



### Readability_issue

La classe `Simple_Strategy` a été écrite par un développeur Python nouvellement converti au Java et présente un problème de lisibilité pour le reste de l'équipe. 

#### Technique(s) utilisée(s) pour poser le diagnostic
*Expliquez comment vous avez identifié le problème. Pensez à indiquer sur quoi vous vous basez pour confirmer la nature du problème (mesures, rapport d'analyse, etc.).*



#### Diagnostic
*Indiquez ci-dessous le problème identifié et les impacts qu'il pourrait avoir sur la maintenabilité du code.*



#### Action(s) corrective(s)
*Indiquez comment corriger le problème. Alternativement, effectuez la correction dans le code source et indiquez-le ci-dessous, nous irons alors voir dans le code directement.*



#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher que cette mauvaise pratique ne se répande dans le projet. Indiquez les techniques et/ou outils à utiliser pour prévenir ce genre de mauvaise pratique. Nous attendons plus ici qu'une réponse générique de type "il faut faire de la review de code" ou "il faut utiliser SonarQube". Par exemple, indiquez ce qu'il faut prendre en compte dans la review et ce sur quoi le reviewer peut se baser pour identifier la mauvaise pratique.*



****************************************************************************************

## Pistes guidées - Code smells

Les codes smells sont issus de la liste [Refactoring Guru](https://refactoring.guru/refactoring/smells/bloaters).

### Il y en a un peu plus je vous le mets quand même ?

Suite à une demande de changement pour implémenter une fonctionnalité permettant de sauver et charger une partie, Jean-Michel Àpeuprès a implémenté la classe `ChessFileHandler`. Allez voir s'il a bien fait ça.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Expliquez comment vous avez identifié le ou les code smells. Pensez à indiquer sur quoi vous vous basez pour confirmer la nature du problème (mesures, rapport d'analyse, etc.).*



#### Diagnostic
*Indiquez ci-dessous le ou les code smells identifiés et les impacts qu'ils pourraient avoir sur la maintenabilité du code.*



#### Action(s) corrective(s)
*Indiquez comment corriger le problème. Alternativement, effectuez la correction dans le code source et indiquez-le ci-dessous, nous irons alors voir dans le code directement.*



#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher que ce ou ces codes smells ne réapparaissent dans le project à l'avenir. Indiquez les techniques et/ou outils à utiliser pour prévenir ce genre de code smells. Nous attendons plus ici qu'une réponse générique de type "il faut faire de la review de code" ou "il faut utiliser SonarQube". Par exemple, indiquez ce qu'il faut prendre en compte dans la review et ce sur quoi le reviewer peut se baser pour identifier les code smells.*



### Quelle est la nature de si ?

Une analyse d'impact faisant suite à une demande d'adaptation du jeu pour supporter un jeu de dames a montré que la méthode `getPieceSymbol` de la classe `ChessView` nécessiterait un grand nombre de modifications si des pièces venaient à être ajoutées, retirées ou modifiées. Allez voir quel est le problème.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Expliquez comment vous avez identifié le ou les code smells. Pensez à indiquer sur quoi vous vous basez pour confirmer la nature du problème (mesures, rapport d'analyse, etc.).*



#### Diagnostic
*Indiquez ci-dessous le ou les code smells identifiés et les impacts qu'ils pourraient avoir sur la maintenabilité du code.*



#### Action(s) corrective(s)
*Indiquez comment corriger le problème. Alternativement, effectuez la correction dans le code source et indiquez-le ci-dessous, nous irons alors voir dans le code directement.*



#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher que ce ou ces codes smells ne réapparaissent dans le project à l'avenir. Indiquez les techniques et/ou outils à utiliser pour prévenir ce genre de code smells. Nous attendons plus ici qu'une réponse générique de type "il faut faire de la review de code" ou "il faut utiliser SonarQube". Par exemple, indiquez ce qu'il faut prendre en compte dans la review et ce sur quoi le reviewer peut se baser pour identifier les code smells.*



### Prepare for trouble, make it double

Le nouveau développeur vous signale que les classes Rook et Bishop lui semblent étrangement similaires. Allez voir de quoi il en retourne.  

#### Technique(s) utilisée(s) pour poser le diagnostic
*Expliquez comment vous avez identifié le ou les code smells. Pensez à indiquer sur quoi vous vous basez pour confirmer la nature du problème (mesures, rapport d'analyse, etc.).*



#### Diagnostic
*Indiquez ci-dessous le ou les code smells identifiés et les impacts qu'ils pourraient avoir sur la maintenabilité du code.*



#### Action(s) corrective(s)
*Indiquez comment corriger le problème. Alternativement, effectuez la correction dans le code source et indiquez-le ci-dessous, nous irons alors voir dans le code directement.*



#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher que ce ou ces codes smells ne réapparaissent dans le project à l'avenir. Indiquez les techniques et/ou outils à utiliser pour prévenir ce genre de code smells. Nous attendons plus ici qu'une réponse générique de type "il faut faire de la review de code" ou "il faut utiliser SonarQube". Par exemple, indiquez ce qu'il faut prendre en compte dans la review et ce sur quoi le reviewer peut se baser pour identifier les code smells.*


****************************************************************************************

## Pistes guidées - Defects

### Welcome to the playground

Suite à la dernière release du projet, l'équipe de développement a reçu le rapport de bug suivant :

Lors de l'exécution du programme, il y a un problème avec l'affichage de la grille. Lorsque je lance le jeu, seules les pièces noires apparaissent. De plus, je vois l'erreur suivante dans la console.

```Java
Exception in thread "AWT-EventQueue-0" java.lang.NullPointerException: Cannot invoke "be.unamur.chess.model.Piece.isWhite()" because "piece" is null
    at be.unamur.chess.ChessView.getPieceSymbol(ChessView.java:61)
    at be.unamur.chess.ChessView.updateBoard(ChessView.java:50)
    at be.unamur.chess.ChessController.startGame(ChessController.java:22)
    at be.unamur.chess.ChessGame.lambda$main$0(ChessGame.java:16)
    at java.desktop/java.awt.event.InvocationEvent.dispatch(InvocationEvent.java:318) <12 more>
```

Pour reproduire le problème :

1. Lancer l'application.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Décrivez la manière dont vous vous y prennez pour trouver le défaut (defect) sous-jacent qui déclenche la défaillance (failure) décrite dans ce rapport de bug lors de l'exécution. Concentrez-vous ici sur ce défaut et cette défaillance en particulier.*



#### Diagnostic
*Indiquez ci-dessous le défaut identifié, ainsi que le ou les tests permettant de le confirmer. Donnez au minimum : les valeurs d'entrées à utiliser pour le ou les tests, le résultat normalement attendu et la manière dont le defect se manifeste (la failure observable). Alternativement, modifiez le code du projet pour ajouter un ou plusieurs tests JUnit et indiquez-le ci-dessous, nous exécuterons alors les tests directement.*



#### Action(s) corrective(s)
*Indiquez comment corriger le défaut. Alternativement, effectuez la correction dans le code source et indiquez-le ci-dessous, nous irons alors voir dans le code directement.*



#### Pratique(s) de développement à modifier
*La défaillance se traduit ici par une NullPointerException. Il s'agit d'une erreur courante en Java. Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe. Indiquez les techniques et/ou outils à utiliser pour prévenir ce genre de défauts. Nous attendons plus ici qu'une réponse générique de type "il faut écrire des tests" ou "il faut faire de la review de code". Par exemple, pour du test, précisez le ou les critères de couverture qui auraient mené à la découverte du défaut.*



### Tenez vos positions !

Suite à la dernière release du projet, l'équipe de développement a reçu le rapport de bug suivant :

Lors de l'exécution du programme, il y a un problème avec le cavalier (Knight). Lorsque l'on clique sur celui-ci et sur la case de destination, le cavalier ne bouge pas et l'erreur suivante apparaît.

```Java
Exception in thread "AWT-EventQueue-0" java.lang.ArrayIndexOutOfBoundsException: Index 8 out of bounds for length 8
    at be.unamur.chess.model.Knight.getValidMoves(Knight.java:25)
    at be.unamur.chess.ChessModel.movePiece(ChessModel.java:82)
    at be.unamur.chess.ChessController.onSquareClick(ChessController.java:32)
    at be.unamur.chess.ChessView.handleSquareClick(ChessView.java:70)
    at be.unamur.chess.ChessView.lambda$initializeBoard$0(ChessView.java:39)
    at java.desktop/javax.swing.AbstractButton.fireActionPerformed(AbstractButton.java:1972) <30 more>
```

Pour reproduire le problème :

1. Lancer l'application.
2. Cliquer sur le cavalier noir.
3. Cliquer sur une case destination valide pour le faire avancer.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Décrivez la manière dont vous vous y prennez pour trouver le défaut (defect) sous-jacent qui déclenche la défaillance (failure) décrite dans ce rapport de bug lors de l'exécution. Concentrez-vous ici sur ce défaut et cette défaillance en particulier.*



#### Diagnostic
*Indiquez ci-dessous le défaut identifié, ainsi que le ou les tests permettant de le confirmer. Donnez au minimum : les valeurs d'entrées à utiliser pour le ou les tests, le résultat normalement attendu et la manière dont le defect se manifeste (la failure observable). Alternativement, modifiez le code du projet pour ajouter un ou plusieurs tests JUnit et indiquez-le ci-dessous, nous exécuterons alors les tests directement.*



#### Action(s) corrective(s)
*Indiquez comment corriger le défaut. Alternativement, effectuez la correction dans le code source et indiquez-le ci-dessous, nous irons alors voir dans le code directement.*



#### Pratique(s) de développement à modifier
*La défaillance se traduit ici par une ArrayIndexOutOfBoundsException. Il s'agit d'une erreur courante en Java. Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe. Indiquez les techniques et/ou outils à utiliser pour prévenir ce genre de défauts. Nous attendons plus ici qu'une réponse générique de type "il faut écrire des tests" ou "il faut faire de la review de code". Par exemple, pour du test, précisez le ou les critères de couverture qui auraient mené à la découverte du défaut.*



### Nous sommes tous fous ici

Suite à la dernière release du projet, l'équipe de développement a reçu le rapport de bug suivant :

Lors de l'exécution du programme, il y a un problème avec le fou (Bishop). Lorsque l'on clique sur le fou pour le déplacer et que l'on clique sur une case cible en diagonale au-delà de la ligne de pions, cela devrait normalement afficher un message d'erreur indiquant que le mouvement est invalide. Ce message ne s'affiche toutefois pas dans la dernière release.

Pour reproduire le problème :

1. Lancer l'application.
2. Cliquer sur le fou noir.
3. Cliquer sur une case située en diagonale au-delà de la ligne de pions qui bloque normalement les mouvements du fou.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Comment pourriez-vous vous y prendre pour trouver ce defect de manière systématique ?*



#### Diagnostic
*Indiquez ci-dessous le defect identifié, ainsi que le ou les tests permettant de le confirmer. Donnez au minimum : les valeurs d'entrées à utiliser pour le ou les tests, le résultat normalement attendu et la manière dont le defect se manifeste (la failure observable). Alternativement, modifiez le code du projet pour ajouter le test JUnit et indiquez-le ci-dessous, nous exécuterons alors le test directement.*



#### Action(s) corrective(s)
*Indiquez comment corriger le défaut. Alternativement, effectuez la correction dans le code source et indiquez-le ci-dessous, nous irons alors voir dans le code directement.*



#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe. Indiquez les techniques et/ou outils à utiliser pour prévenir ce genre de défauts. Nous attendons plus ici qu'une réponse générique de type "il faut écrire des tests" ou "il faut faire de la review de code". Par exemple, pour du test, précisez le ou les critères de couverture qui auraient mené à la découverte du défaut.*


****************************************************************************************

## Analyse complémentaire

*Cette dernière question est ouverte et vous demande de faire une analyse globale de la qualité du projet sur base des différents rapports d'analyse qui vous sont fournis. Vous pouvez également indiquer des recommandations à mettre en place (pratiques de développement à modifier) afin d'améliorer et de maintenir le niveau de qualité du projet.*
